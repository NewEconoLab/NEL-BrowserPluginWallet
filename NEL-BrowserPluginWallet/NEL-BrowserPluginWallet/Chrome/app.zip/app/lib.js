class NeoP {
  // constructor(x, y) {
  //   this.x = x;
  //   this.y = y;
  // }

  getTest() {
    return 'test';
  }
}